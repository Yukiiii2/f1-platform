# CPA Study Hub

A full-stack CPALE study-management and learning platform.

## Planned capabilities

- editable study calendar
- CPA subject/topic tracking
- lecture/video progress
- PDF/CSV resource library
- quizzes
- flashcards
- spaced repetition
- assessments
- study analytics
- source-grounded AI assistance

## Architecture

```text
frontend/  Next.js + React + TypeScript
backend/   FastAPI + Python
database   Supabase PostgreSQL
auth       Supabase Auth
storage    Supabase Storage
deploy     Vercel frontend + Vercel backend
```

Frontend and backend are separate applications in one repository.

## Documentation

Read first:

- `AGENTS.md`
- `PRODUCT.md`
- `ARCHITECTURE.md`
- `ROADMAP.md`

Frontend:

- `DESIGN.md`
- `DESIGN_GUIDELINES.md`

Backend/data:

- `DATABASE.md`
- `API.md`
- `IMPORTS.md`
- `AI.md`
- `DATA_AND_TELEMETRY.md`

Operations:

- `DEPLOYMENT.md`
- `GIT_WORKFLOW.md`

## Status

Documentation/foundation planning stage.

Implementation follows `ROADMAP.md` phase-by-phase.

## Environment

Never commit real secrets.

Frontend variables:

```text
NEXT_PUBLIC_API_URL=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
```

Backend variables:

```text
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
DATABASE_URL=
GEMINI_API_KEY=
CORS_ORIGINS=
```

Actual environment files are created during implementation and remain Git-ignored.
